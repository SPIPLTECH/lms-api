# Restoration Prompt — Give This To Claude Code Verbatim

You are restoring 12 AI agent modules that were deliberately, temporarily removed from this
LMS (`lms-api` Express/Prisma backend + `lms_web_demo` Next.js frontend). A complete backup
and restoration package exists at `lms-api/backup/ai-agents/`. Read it before doing
anything.

**Do not redesign these agents. Restore them according to the backed-up architecture and
behavior, exactly as documented, unless the user explicitly instructs otherwise.** This is a
restoration, not a rebuild-from-scratch or an "improve while you're at it" task.

## Read these files first, in this order

1. `backup/ai-agents/README.md` — overview and the two critical exceptions (kept DB tables,
   entry-assessment carve-out).
2. `backup/ai-agents/ARCHITECTURE.md` — the real dependency graph, orphaned-code notes
   (analytics/learning-path/mentor's dual chains — restore them exactly as found, don't
   "fix" the duplication), and the entry-assessment carve-out explanation.
3. `backup/ai-agents/DEPENDENCY_MAP.md` — per-agent file structure, public surface, events,
   who-consumes-whom.
4. `backup/ai-agents/DATABASE.md` — exactly which Prisma models/enums to re-add, and the
   critical list of what was NEVER removed (`LearningEvent`, `StudentActivityState`,
   `ConceptMastery`, `KnowledgeGap`, `StudentState`, `EntryAssessment`,
   `StudentCourseState`) — verify these already exist in the current schema before assuming
   they need restoring; do not create duplicates.
5. `backup/ai-agents/API_REFERENCE.md`, `PROMPTS.md`, `CONFIGURATION.md`, `ENVIRONMENT.md`
   — the operational details.
6. `backup/ai-agents/RESTORATION_STEPS.md` — the ordered checklist. Follow it in order.
7. `backup/ai-agents/VALIDATION.md` — how to confirm each step actually worked. Run these
   checks after restoring, and report actual results, not assumed ones.
8. `backup/ai-agents/MANIFEST.md` — the complete file list, so you can verify nothing was
   missed.

## The 12 agents, in original build order

1. **Observation** (`modules/observation`) — passive event-recording sink, no bootstrap.
2. **Student State** (`modules/student-state`) — per-student aggregate state (engagement/
   performance/risk).
3. **Assessment** (`modules/assessment`) — concept mastery / knowledge gap tracking from
   quiz/assignment attempts. *(Note: the entry-assessment onboarding feature that used to
   live inside this folder was extracted to `modules/entry-assessment/` and is NOT part of
   what you're restoring — it's already live in the current codebase.)*
4. **Recommendation** (`modules/recommendation`) — ranked candidate recommendations.
5. **Motivation** (`modules/motivation`) — nudges/streaks, the first agent to consume a
   live peer's event bus for real (subscribes to Recommendation).
6. **Teacher Insights** (`modules/teacher-insights`) — course/teacher-scoped, breaks the
   per-student pattern; inverted access control (instructor/admin only).
7. **Analytics** (`modules/analytics`) — spans all 4 scope levels at once, read-only,
   aggregates the other agents' own already-computed data.
8. **Career Guidance** (`modules/career`) — uses `ai/` instead of `services/domain/` (a
   deliberate one-off, not a convention to replicate elsewhere).
9. **Learning Path** (`modules/learning-path`) — six other agents had defensive
   `try { require("../../learning-path") } catch {}` stubs against it before it existed.
10. **Placement** (`modules/placement`) — structural sibling of Career, consumes
    `career.getFullState`.
11. **Admin Intelligence** (`modules/admin-intelligence`) — sits one layer above Analytics,
    consumes `analytics.getPlatformKPIs/getCourseKPIsBatch/getInstructorKPIsBatch`,
    `teacherInsights.getTeacherDashboard`, `studentState.getHighRiskStudents`. ADMIN-only.
12. **AI Mentor** (`modules/mentor`) — conversational orchestrator sitting above all 11
    others, ownership-based access (not role-gated, unlike every other agent), first SSE
    endpoint in the codebase.

## Critical constraints — do not violate these

1. **Do not re-add `LearningEvent`, `StudentActivityState`, `ConceptMastery`,
   `KnowledgeGap` as if they were removed** — they were deliberately kept because a
   separate feature (`modules/learner-model`) depends on them directly. Check the current
   schema first.
2. **Do not touch `modules/entry-assessment/`** — it's the extracted onboarding-assessment
   feature, live and working, unrelated to this restoration. If you find yourself wanting
   to modify it while restoring `assessment`/`student-state`, stop and re-read
   `ARCHITECTURE.md`'s "Entry-Assessment Carve-Out" section.
3. **Preserve the orphaned dual code chains in `analytics`, `learning-path`, and
   `mentor`** exactly as backed up — do not delete the dead one or merge them. This is
   how the code actually was; "cleaning it up" during restoration would not be a faithful
   restoration.
4. **Preserve bootstrap order and debounce cadences** from `CONFIGURATION.md` exactly.
5. **Do not invent missing information.** If something in the backup is ambiguous or a
   file seems to be missing, say so explicitly (`UNKNOWN — REQUIRES MANUAL VERIFICATION`)
   rather than guessing or fabricating behavior, an API shape, a prompt, or a schema field.
6. **No test suite existed for any of these 12 agents before removal** — don't fabricate
   one during restoration unless the user separately asks for test coverage as a new task.
7. **This project uses `prisma db push`, not `prisma migrate`** — no migrations folder
   exists or should be created.
8. **`modules/auth/auth.controller.js` (core, not one of the 12) had a real dependency on
   Observation** (`publishEvent`/`EVENT_TYPES` for login/logout event logging) that was
   removed along with the agents — this is NOT restored automatically by copying agent
   source back. See `DEPENDENCY_MAP.md`'s "Core-module touchpoint" section and
   `reference/core-module-touchpoints/auth.controller.js.pre-removal` for the exact code.
   This was found by an actual boot-check after deletion, not by static grepping — run the
   same boot-check (`node -e "require('./src/app.js')"` from `lms-api/`) after restoring
   to catch anything else like it.
9. Both `lms-api` and `lms_web_demo` are separate git repos. Check `git status` in both
   before making changes, same discipline as any other work in this codebase. Do not
   commit automatically — only when the user explicitly asks.

## Expected behavior after restoration

The system should behave exactly as described in `ARCHITECTURE.md` and `DEPENDENCY_MAP.md`
— same event flow, same access control per agent, same debounce timing, same API shapes.
Validate using `VALIDATION.md`'s checklist and report actual results.

## Build/run requirements

- Backend: `npm run dev` (nodemon) or `npm start`, from `lms-api/`.
- Frontend: `npm run dev`, from `lms_web_demo/`.
- After schema restoration: `npx prisma db push && npx prisma generate` from `lms-api/`.
- `ANTHROPIC_API_KEY` is optional (see `ENVIRONMENT.md`) — set it in `.env` if real
  Anthropic-backed responses (mentor's unwired chain, entry-assessment's LLM question
  generation) are wanted; otherwise both fall back to their documented non-generative
  defaults automatically.
