# API Reference — Removed Routes

All 12 mount points, exactly as they were in `app.js` before removal (full pre-removal file
at `reference/app.js.pre-removal`). Sub-route detail (individual GET/POST paths within each
router) is in each agent's own `routes/` folder under `source/<agent>/routes/`.

| # | Agent | Mount prefix | Auth model | Notes |
|---|---|---|---|---|
| 1 | observation | `/events` | verifyToken (per-route) | No bootstrap; router-only. |
| 2 | student-state | `/student-state` | Student-scoped (`resolveStudentAccess`) | `GET /course/:courseId` was carved out to `modules/entry-assessment/` before removal — not part of what's removed, still live. |
| 3 | assessment | `/assessment` | Student-scoped | `/entry/*` sub-router was carved out to `modules/entry-assessment/` before removal — not part of what's removed, still live. Remaining routes removed: `GET /mastery`, `GET /history`, `GET /knowledge-gaps`, `GET /recommendations`, `GET /reassessment-plan`, `POST /evaluate`, `POST /recalculate`, `GET /:studentId`. |
| 4 | recommendation | `/recommendations` | Student-scoped | |
| 5 | motivation | `/motivation` | Student-scoped | |
| 6 | teacher-insights | `/teacher-insights` | INSTRUCTOR (own courses only) / ADMIN — zero student access | Frontend consumer: `GET /teacher-insights/:teacherId`. |
| 7 | analytics | `/analytics` | Three-way split: STUDENT own-scope, INSTRUCTOR own-instructor+own-course scope, PLATFORM-scope+export ADMIN-only | |
| 8 | career | `/career` | Student-scoped | |
| 9 | learning-path | `/learning-path` | Student-scoped | Frontend consumer: `GET /learning-path/:studentId`. |
| 10 | placement | `/placement` | Student-scoped | |
| 11 | admin-intelligence | `/admin-intelligence` | ADMIN-only, no student/instructor branching | |
| 12 | mentor | `/mentor` | Ownership-based (any role, own conversations only) | Frontend consumers: `POST /mentor/conversations`, `GET /mentor/conversations`, `GET /mentor/conversations/:id/messages`, `POST /mentor/conversations/:id/messages`, `POST /mentor/conversations/:id/messages/stream` (SSE). |

## Cross-agent internal API (not HTTP — `index.js` public-surface getters)

See `DEPENDENCY_MAP.md` for the full per-agent export list and who calls what. Summary of
the load-bearing ones:
- `studentState.getFullState/getBatchStates/getHighRiskStudents`
- `assessment.getFullState/getKnowledgeGaps/getRecommendations/getBatchAssessmentSummary`
- `recommendation.getByStudent/getBatchActiveRecommendations`
- `motivation.getStreak/getBatchMotivationSummary`
- `teacherInsights.getTeacherDashboard`
- `analytics.getPlatformKPIs/getCourseKPIsBatch/getInstructorKPIsBatch`
- `career.getFullState`
- `learningPath.getFullState/getBatchStates`

## SSE / streaming

Only one streaming endpoint existed across all 12 agents: `mentor`'s
`POST /mentor/conversations/:id/messages/stream`, plain Express (`res.write()` +
`text/event-stream`), not the app's existing Socket.IO layer. Streams real Anthropic token
deltas when `ANTHROPIC_API_KEY` is set via the (unwired) subfolder chain, or the Ollama
gateway's response via the active flat chain — see ARCHITECTURE.md for the dual-chain
detail. Frontend consumer: `src/components/mentor/MentorWindow.jsx`
(`streamMentorMessage` in `src/services/mentor.service.js`), backed up at
`source/frontend/mentor/`.
