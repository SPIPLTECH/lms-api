# Architecture — As Actually Implemented (not idealized)

This describes the system exactly as it was found in the codebase before removal. Nothing
here is invented — every claim traces to a specific file.

## Overall shape

```
                              ┌───────────────────────┐
                              │      AI Mentor         │
                              │  Conversational        │
                              │  Orchestrator           │
                              │  (consumer-only —       │
                              │   no subscribe/events)  │
                              └───────────┬─────────────┘
                                          │ calls public getters of:
        ┌──────────────┬──────────────┬──┴───────────┬──────────────┬──────────────┐
        ▼              ▼              ▼               ▼              ▼              ▼
   Observation   Student State   Assessment    Recommendation   Motivation   Teacher Insights
   (event sink,  (aggregate      (mastery/gap  (candidate/rank  (nudges,     (course/teacher-
   no bootstrap) state, risk)    tracking)     recs)            streaks)     scoped alerts)
        │              │              │               │              │              │
        └──────────────┴──────────────┴───────┬───────┴──────────────┴──────────────┘
                                               │ STATE_UPDATED / EVENT_CREATED fan-out
                                               ▼
                                          Analytics
                                (aggregates the aggregators — reads
                                 Observation's tables directly, plus
                                 Assessment/Motivation/StudentState/
                                 TeacherInsight getters)
                                               │
                              ┌────────────────┴────────────────┐
                              ▼                                 ▼
                     Admin Intelligence                   (other future
                (consumes Analytics.getPlatformKPIs/       consumers)
                 getCourseKPIsBatch/getInstructorKPIsBatch,
                 TeacherInsight.getTeacherDashboard,
                 StudentState.getHighRiskStudents)

        Career ──skillMatch/roadmap──> (own IndustryRole seed data)
        Learning Path ──sequencing──> (reads Assessment/StudentState/Recommendation getters)
        Placement ──jobMatch──> (reads Career.getFullState)
```

Mentor sits **above** all 11 others as a pure consumer — it has no `subscribe`/event-names
export of its own (confirmed: no `events/eventNames.js` file exists in `mentor/`). Every
other agent (recommendation, motivation, teacher-insights, analytics, career, learning-path,
placement, admin-intelligence) both publishes its own `*_EVENT_NAMES` and subscribes to
`student-state`'s `STATE_UPDATED` (and usually `observation`'s `EVENT_CREATED`) to trigger
its own debounced recalculation.

## Per-agent established pattern (identical across all 12)

- Own in-process `EventEmitter`-based pub/sub bus (`events/eventBus.js`), never shared
  across agents — each agent is independently deployable in principle.
- Own copies of near-identical middleware (`resolveStudentAccess`/`resolveTeacherAccess`/
  `resolveCourseAccess`, `validateQuery`) rather than sharing one implementation.
- Folder structure: `constants/ types/ utils/ services/ repositories/ dto/ events/
  schedulers/ middleware/ validators/ controllers/ routes/`. (No agent has a `tests/`
  folder — zero test coverage existed for any of the 12.)
- Cross-agent reads happen only through another agent's `index.js` public surface
  (`subscribe`, a handful of named getters) — never by reaching into another agent's
  internals, with one documented exception: `analytics`'s calculators
  (`services/domain/calculators/platform.calculator.js`,
  `services/domain/calculators/course.calculator.js`) call `prisma.learningEvent`/
  `prisma.studentActivityState` directly rather than through an Observation getter.
- Each module's `bootstrap()` was called once in `server.js`; its router mounted in
  `app.js`. `observation` is the only agent with no `bootstrap()` (it has no
  scheduler/consumer of its own — purely a passive event-recording sink plus router).
- `node:test`/`node:assert` was the intended test runner for this project generally, but
  none of the 12 agents ever had tests written.

## Admin Intelligence -> Analytics relationship (preserve exactly on restore)

Admin Intelligence was built explicitly as a layer *above* Analytics, applying the same
"aggregate the aggregators" principle one level up: it never re-derives what
Assessment/Motivation/Recommendation/Career/Placement/Learning Path already feed into
Analytics — it consumes Analytics' own already-computed KPIs plus Teacher Insight's
`getTeacherDashboard()` and Student State's `getHighRiskStudents()`. Three getters were
added to `analytics/index.js` specifically for this (`getPlatformKPIs`, `getCourseKPIsBatch`,
`getInstructorKPIsBatch`) since Analytics previously only exported `recalculate`/
`generateForScope`/`subscribe`.

## Known structural oddities — preserved as-found, not "fixed" during backup

- **`analytics` and `learning-path`** each contain a duplicate, dead flat-file
  route/controller/service chain at the module root (e.g. `analytics/analytics.routes.js`)
  alongside the real, active one in `routes/`/`controllers/`/`services/`. The flat files
  have zero incoming requires from anywhere — genuinely orphaned code, not a second live
  path. Restore both copies as-is; do not delete the dead one, and do not try to reconcile
  them into one.
- **`mentor` is the inverse case**: its flat-file chain (`mentor.routes.js` ->
  `mentor.controller.js` -> `mentor.service.js` -> `tools/tool.registry.js` +
  `mentorPrompt.builder.js`, using the shared Ollama-backed `modules/llm` service) is the
  one actually mounted (`mentor/index.js:1` requires the flat `mentor.routes.js`). The more
  elaborate subfolder chain (`routes/mentor.routes.js` -> `controllers/mentor.controller.js`
  -> `services/mentor.service.js` -> `orchestrator/`, `context-engine/`, `intent-engine/`,
  `memory/`, and `mentor/llm/anthropicProvider.js` — the only Anthropic-SDK-using code
  inside `mentor/`) is what `mentor/index.js`'s `chat`/`streamChat` exports actually come
  from, but nothing outside `mentor/` ever called those exports (confirmed by repo-wide
  grep) — so this had zero external blast radius while live. On restore, both chains must
  come back exactly as they were: the router mounted from the flat files, the exported
  `chat`/`streamChat` functions sourced from the subfolder files. Do not try to unify them
  — that would be a redesign, not a restoration.

## Entry-Assessment Carve-Out (context for restoration, not part of what's restored)

Before the 12 agents were removed, a separate feature — "AI Student Entry Phase"
(course-enrollment onboarding assessment, built 2026-08-03, not one of the 12 agents) — had
its backend code physically nested inside two of the agent module folders:
`modules/assessment/` (controller/service/repository/routes/validator + a whole `llm/`
folder for question generation) and `modules/student-state/` (a `getCourseState` handler
embedded directly in the main agent's own controller/routes files, plus a dedicated
`studentCourseState.service.js`/`repository.js`).

This code was extracted into a new standalone module, `modules/entry-assessment/`, mounted
at the exact same URLs (`/assessment/entry/*`, `GET /student-state/course/:courseId`) so the
frontend needed zero changes. **This extracted module is live in the current codebase and is
NOT part of this backup or restoration** — do not restore a copy of it from `source/
assessment/` or `source/student-state/`, since those source snapshots include the
entry-assessment files exactly as they looked *before* extraction (for historical reference
only). If you need the current, live entry-assessment code, read
`lms-api/src/modules/entry-assessment/` directly in the live repo, not this backup.

The one thing restoration DOES need to know: `modules/entry-assessment/` publishes no event
and depends on nothing from the restored agents. Restoring the 12 agents does not require
any change to `entry-assessment/`, and `entry-assessment/` does not need to be told the
agents came back (its `initializeCourseState` no longer publishes `STATE_UPDATED` since no
subscriber needed it after the agents were removed — if you want the original
event-driven hand-off back, you would need to re-add that publish call to
`entry-assessment/services/studentCourseState.service.js` yourself; this is called out here
because it is a deliberate behavior change from the original design, not an oversight).
