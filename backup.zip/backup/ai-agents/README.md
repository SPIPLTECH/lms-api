# AI Agent System — Backup & Restoration Package

This directory is a complete backup of the 12 AI agent modules that were removed from
`lms-api` (and their frontend integration in `lms_web_demo`) on 2026-08-25, plus everything
needed to restore them later to work exactly as they did before removal.

## Why this exists

The 12 agents were temporarily removed from the active LMS. This package preserves:
- Full source code for all 12 backend modules (`source/<agent>/`)
- Reference snapshots of `schema.prisma`, `package.json`, `app.js`, `server.js` from
  immediately before removal (`reference/`)
- Complete documentation of architecture, database schema, APIs, environment variables,
  prompts, and configuration (this directory's other `.md` files)
- A self-contained restoration prompt (`AGENT_RESTORATION_PROMPT.md`) that a future Claude
  Code session can be given directly to rebuild the whole system

## How to use this package

To restore the agents, give a Claude Code session the contents of
`AGENT_RESTORATION_PROMPT.md` as its task. Read `RESTORATION_STEPS.md` for the ordered
checklist and `VALIDATION.md` for how to confirm each agent works after restoring.

## Important: what did NOT leave the codebase

Two things related to this system were deliberately **not** removed, and restoration must
not try to re-add them:

1. **`LearningEvent`, `StudentActivityState`, `ConceptMastery`, `KnowledgeGap`** — these 4
   Prisma models, nominally owned by the Observation and Assessment agents, were **kept in
   the live schema** because a separate, unrelated feature (`modules/learner-model`, a
   Bayesian Knowledge Tracing system, not one of the 12 agents) reads/writes them directly
   via raw `prisma.*` calls with no dependency on the agent module code itself. See
   `DATABASE.md` for the full reasoning.
2. **The AI Student Entry Phase feature** (course-enrollment onboarding assessment) had its
   backend code extracted from inside `modules/assessment/` and `modules/student-state/`
   into a new standalone module, `modules/entry-assessment/`, which **remains active** in
   the codebase today. It is not part of this backup and not part of restoration — see
   `ARCHITECTURE.md`'s "Entry-Assessment Carve-Out" section.

## Package contents

```
backup/ai-agents/
├── README.md                    (this file)
├── AGENT_RESTORATION_PROMPT.md  (self-contained restore prompt for a future Claude session)
├── ARCHITECTURE.md              (dependency graph, orchestration, orphaned-code notes)
├── DEPENDENCY_MAP.md            (per-agent files, public surface, events, cross-agent calls)
├── DATABASE.md                  (per-agent Prisma models/enums, what was kept vs removed)
├── ENVIRONMENT.md               (env vars used, none secret)
├── API_REFERENCE.md             (every route, per agent)
├── PROMPTS.md                   (mentor prompt templates, LLM prompt-builder logic)
├── CONFIGURATION.md             (bootstrap order, scheduler cadences, debounce windows)
├── RESTORATION_STEPS.md         (ordered restore checklist)
├── VALIDATION.md                (how to confirm each agent works post-restore)
├── MANIFEST.md                  (every backed-up file, original path -> backup path)
├── reference/
│   ├── schema.prisma.pre-removal   (full schema exactly as it was before removal)
│   ├── package.json.pre-removal
│   ├── app.js.pre-removal
│   ├── server.js.pre-removal
│   ├── env-keys-only.txt           (env var NAMES only, values redacted)
│   └── core-module-touchpoints/    (core (non-agent) code that had a real dependency
│                                     on a removed agent — see DEPENDENCY_MAP.md)
├── data/                (every row from every removed table, exported to JSON right
│                          before the destructive db push — one file per table, plus
│                          _export-summary.json; see RESTORATION_STEPS.md step 3a)
└── source/
    ├── observation/       (full pre-removal source tree, verbatim)
    ├── student-state/
    ├── assessment/
    ├── recommendation/
    ├── motivation/
    ├── teacher-insights/
    ├── analytics/
    ├── career/
    ├── learning-path/
    ├── placement/
    ├── admin-intelligence/
    ├── mentor/
    └── frontend/           (removed lms_web_demo files, by agent)
```
