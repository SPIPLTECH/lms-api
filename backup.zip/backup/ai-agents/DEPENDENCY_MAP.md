# Dependency Map

Per-agent: folder structure, public surface (`index.js` exports), event names, and which
other agents it consumed/was consumed by. Source of truth: `source/<agent>/` in this backup.

## Core-module touchpoint found during removal (missed by the pre-removal investigation)

`modules/auth/auth.controller.js` (a core module, not one of the 12) directly required
`../observation` for `publishEvent`/`EVENT_TYPES`, firing a fire-and-forget
`USER_LOGIN`/`USER_LOGOUT` event on every student login/logout. The pre-removal dependency
sweep (grepping for `modules/observation`-style paths) missed this because it's a
one-level-up relative require (`require("../observation")`) from a module of the same
nesting depth as the agents themselves — the sweep's relative-path check did not
exhaustively cover every core module at that depth. This was only caught by an actual
boot-check (`node -e "require('./src/app.js')"`) after deleting the module directories,
which is why that boot-check step matters and shouldn't be skipped in future removals.

Fix applied: removed the `observeAuthEvent` helper and its two call sites (login, logout)
from `auth.controller.js` — this was purely an integration *into* Observation, not a
feature auth needs for its own sake. The original code is preserved at
`reference/core-module-touchpoints/auth.controller.js.pre-removal` for restoration
reference. **On restoring the 12 agents, re-add this integration to
`modules/auth/auth.controller.js`** (not part of the standard per-agent restore, since
`auth` isn't one of the 12 — this is called out separately here and in
`RESTORATION_STEPS.md`).

## 1. observation — `modules/observation`
- Folders: `constants/ controller/ dto/ events/ index.js middleware/ repository/ routes/
  service/ types/ utils/ validation/`. No `tests/`.
- Exports: `router, publishEvent, subscribe, getStudentEventLog, getEventById,
  OBSERVATION_EVENT_NAMES, EVENT_TYPES, EVENT_CATEGORIES`. **No `bootstrap()`** — passive
  sink only.
- Events: `OBSERVATION_EVENT_NAMES.EVENT_CREATED`, `.STATE_UPDATED`.
- Mounted: `app.js` -> `app.use("/events", observation.router)`.
- Consumed by: every other agent's `events/eventConsumer.js` subscribes to
  `OBSERVATION_EVENT_NAMES.EVENT_CREATED` to trigger its own recalculation.
  `analytics`'s calculators also read its Prisma tables (`LearningEvent`,
  `StudentActivityState`) directly, bypassing the getter surface.
- `publishEvent` callers found: only from within the 12-agent set (e.g. `mentor` publishes
  `AI_HINT_REQUESTED`/`AI_CHAT_*` on every student chat turn). No core LMS module ever
  called `publishEvent` directly.

## 2. student-state — `modules/student-state`
- Folders: `constants/ controllers/ dto/ events/ index.js middleware/ repositories/ (7)
  routes/ schedulers/ (reconciliation.scheduler.js) services/ (domain/, reducers/,
  scoreCalculator.service.js, studentCourseState.service.js, studentState.service.js)
  types/ utils/ validators/`.
- Exports: `router, bootstrap, subscribe, STUDENT_STATE_EVENT_NAMES, recalculate,
  getRiskSnapshot, getFullState, getBatchStates, getHighRiskStudents,
  initializeCourseState, getCourseState`. The last two (`initializeCourseState`/
  `getCourseState`) were the entry-assessment carve-out's functions — see
  ARCHITECTURE.md.
- Events: `STUDENT_STATE_EVENT_NAMES.STATE_UPDATED`.
- Mounted: `app.js` -> `/student-state`; bootstrapped in `server.js`.
- Consumed by: recommendation, assessment, motivation, teacher-insights (batch getters),
  analytics, career, learning-path, placement, admin-intelligence (`getHighRiskStudents`)
  all subscribe to `STATE_UPDATED` and/or call `getFullState`/`getBatchStates`.

## 3. assessment — `modules/assessment`
- Folders: `constants/ controllers/ dto/ events/ index.js middleware/ repositories/ (7)
  routes/ schedulers/ services/ (assessment.service.js, domain/ — 10 files) types/ utils/
  validators/`. (`llm/` and the `entryAssessment.*` files were the carve-out — see
  ARCHITECTURE.md; not part of this agent's real surface.)
- Exports: `router, bootstrap, subscribe, ASSESSMENT_EVENT_NAMES, recalculate,
  getFullState, getKnowledgeGaps, getRecommendations, getBatchAssessmentSummary`.
- Events: `ASSESSMENT_EVENT_NAMES.ASSESSMENT_UPDATED`, `.ENTRY_ASSESSMENT_EVALUATED`
  (latter was carve-out-only, no longer published post-removal).
- Mounted: `app.js` -> `/assessment`; bootstrapped in `server.js`.
- Consumed by: recommendation, career, learning-path, mentor (`getFullState`), and others
  via `subscribe`.
- **No LLM dependency in the real agent** — `assessment/llm/` (Anthropic SDK) belonged
  entirely to the entry-assessment carve-out; the agent's own mastery/gap evaluation is
  pure deterministic domain math (`masteryReducer.js`, `confidence.js`, `gapDetector.js`,
  etc.), confirmed by exhaustive grep — zero `llm` requires anywhere in the real agent's
  domain engines.

## 4. recommendation — `modules/recommendation`
- Folders: `constants/ controllers/ dto/ events/ index.js middleware/ repositories/ (5)
  routes/ schedulers/ (dailyDigest, deadlineScan) services/ (context/
  studentContextBuilder.js, domain/generators/ — 11 files, rankingEngine.js,
  scoringEngine.js) types/ utils/ validators/`.
- Exports: `router, bootstrap, subscribe, RECOMMENDATION_EVENT_NAMES, recalculate,
  generateForStudent, getByStudent, getBatchActiveRecommendations`.
- Events: `RECOMMENDATION_EVENT_NAMES.RECOMMENDATION_UPDATED`.
- Mounted: `app.js` -> `/recommendations`; bootstrapped in `server.js`.
- Consumed by: motivation (subscribes to its bus — the first agent to consume a live
  peer's event bus for real). Career's own recommendation pipeline reuses this agent's
  exact candidate shape (`{type, dedupeKey, urgency, impact, confidence}` -> scored ->
  ranked -> upserted -> retired-and-snapshotted) as a pattern, not a code dependency.

## 5. motivation — `modules/motivation`
- Folders: `constants/ controllers/ dto/ events/ index.js middleware/ repositories/ (6)
  routes/ schedulers/ (deadlineScan, engagementSweep, reminderDispatch) services/
  (context/, domain/detectors/ — 10 files) types/ utils/ validators/`.
- Exports: `router, bootstrap, subscribe, MOTIVATION_EVENT_NAMES, recalculate,
  generateForStudent, getBatchMotivationSummary, getStreak`.
- Events: `MOTIVATION_EVENT_NAMES.MOTIVATION_UPDATED`.
- Mounted: `app.js` -> `/motivation`; bootstrapped in `server.js`.
- Consumed by: analytics (`getStreak`), recommendation's own thresholds reference
  motivation-adjacent event types.

## 6. teacher-insights — `modules/teacher-insights`
- Folders: `constants/ controllers/ dto/ events/ index.js middleware/
  (resolveCourseAccess, resolveTeacherAccess, validateQuery) repositories/ (7) routes/
  schedulers/ (dailyClassSweep, monthlySummary, weeklySummary) services/ (context/
  courseContextBuilder.js, domain/detectors/ — 11 files, rankingEngine.js) types/ utils/
  validators/`.
- Exports: `router, bootstrap, subscribe, TEACHER_INSIGHT_EVENT_NAMES, recalculate,
  generateForCourse, getTeacherDashboard`.
- Events: `TEACHER_INSIGHT_EVENT_NAMES.TEACHER_INSIGHT_UPDATED`.
- Mounted: `app.js` -> `/teacher-insights`; bootstrapped in `server.js`.
- **Breaks the per-student pattern**: course/teacher-scoped, aggregates every enrolled
  student per course rather than tracking one student at a time. Required adding
  batch-read methods to student-state/assessment/recommendation/motivation
  (`getBatchStates`, `getBatchAssessmentSummary`, `getBatchActiveRecommendations`,
  `getBatchMotivationSummary`), each backed by one `WHERE studentId IN (...)` query, not a
  per-student fan-out. **Access control is inverted**: only the owning INSTRUCTOR
  (`Course.creatorId === User.id`) or ADMIN can access `/teacher-insights/*` — zero
  student access, unlike every student-scoped agent.
- Consumed by: analytics (`getTeacherDashboard` for course-health/engagement metrics),
  admin-intelligence (`getTeacherDashboard`, real `confidenceScore` scan for AI-decision
  audit).

## 7. analytics — `modules/analytics`
- Folders: `constants/ dto/ events/ exporters/ (csv, json) index.js middleware/
  (resolveAnalyticsAccess, resolveCourseAccess, resolveScopeAccess, validateQuery)
  repositories/ (7) schedulers/ (courseInstructorSweep, platformDailySweep,
  reportScheduler) services/ (domain/calculators/ — 4 files, forecastEngine.js,
  reportPeriod.js, trendDetector.js) types/ utils/ validators/`. Plus the active
  `controllers/analytics.controller.js` / `routes/analytics.routes.js` and the orphaned
  flat duplicates at module root (`analytics.controller.js`, `analytics.routes.js`) — see
  ARCHITECTURE.md.
- Exports: `router, bootstrap, subscribe, ANALYTICS_EVENT_NAMES, recalculate,
  generateForScope, getPlatformKPIs, getCourseKPIsBatch, getInstructorKPIsBatch`.
- Events: `ANALYTICS_EVENT_NAMES.ANALYTICS_UPDATED`.
- Mounted: `app.js` -> `/analytics`; bootstrapped in `server.js`.
- **Spans all 4 scope levels at once** (student/instructor/course/platform), explicitly
  read-only (hard constraint: "must NEVER modify data or generate recommendations"). One
  generic `(scopeType, scopeId)` schema instead of four parallel model families — no
  hard FK on `scopeId` (polymorphic, same precedent as teacher-insights'
  `InsightHistory`). Aggregates the aggregators: student-level reads go through
  `motivation.getStreak` + `studentState.getFullState`/`assessment.getFullState`;
  instructor-level reuses `teacherInsights.getTeacherDashboard`. Only metrics no peer
  agent owns (enrollment, DAU/MAU, AI usage, revenue, dropout, course difficulty) query
  LMS tables directly, plus `observation`'s `LearningEvent`/`StudentActivityState`
  directly (the one documented exception to the getter-only rule).
- Two-tier recompute: STUDENT-scope event-driven with 5s debounce; COURSE/INSTRUCTOR-scope
  60s-debounced off `TeacherInsightUpdated` + hourly sweep; PLATFORM-scope daily-sweep
  only.
- Consumed by: admin-intelligence (`getPlatformKPIs`, `getCourseKPIsBatch`,
  `getInstructorKPIsBatch` — these 3 getters were added specifically for
  admin-intelligence, previously analytics had no read getters at all).
- Report export: JSON and CSV only, hand-rolled CSV serializer (no PDF-writer dependency
  exists in this repo).

## 8. career — `modules/career`
- Folders: `ai/ (generators/ — 4 files, jobMarketProvider.js, rankingEngine.js,
  readinessScorer.js, roadmapGenerator.js, scoringEngine.js, skillGapAnalyzer.js,
  skillMatchEngine.js) constants/ (industryRoles.seed.js) controllers/ dto/ events/
  index.js middleware/ repositories/ (9) routes/ schedulers/ (dailySafetySweep,
  industryTaxonomyRefresh) services/ (career.service.js, context/
  studentContextBuilder.js) types/ utils/ validators/`. Uses `ai/` instead of the usual
  `services/domain/` — a deliberate one-off per this agent's own spec wording, not a
  standing convention.
- Exports: `router, bootstrap, subscribe, CAREER_EVENT_NAMES, recalculate,
  generateForStudent, getFullState`. `getFullState` was added specifically for Placement
  to consume (didn't exist before Placement needed it).
- Events: `CAREER_EVENT_NAMES.CAREER_PROFILE_UPDATED`.
- Mounted: `app.js` -> `/career`; bootstrapped in `server.js`.
- Domain-fabrication resolution (no real Skill/Project/Portfolio/Resume model exists in
  this LMS): technical skills derived from Assessment's `ConceptMastery`, snapshotted
  into career's own `SkillAssessment` table. "Industry Skill Taxonomy" is career's own
  seeded reference data (`industryRoles.seed.js`), idempotently upserted every boot.
  "Job Market Trends" is a real adapter seam (`ai/jobMarketProvider.js`) defaulting to
  static seed data — a real provider swaps in with zero other changes. Skill-name
  matching is normalized-string equality (no canonical skill-ID taxonomy exists to join
  by ID).
- Consumed by: placement (`getFullState`).

## 9. learning-path — `modules/learning-path`
- Folders: `constants/ controllers/learningPath.controller.js (active) dto/ events/
  index.js middleware/ repositories/ (6) routes/learningPath.routes.js (active)
  schedulers/ (dailySweep) services/context/studentContextBuilder.js
  services/domain/ (8 files) services/learningPath.service.js (active) types/ utils/
  validators/`. Plus orphaned flat duplicates at module root — see ARCHITECTURE.md.
- Exports: `router, bootstrap, subscribe, LEARNING_PATH_EVENT_NAMES, recalculate,
  generateForStudent, getFullState, getBatchStates`.
- Events: `LEARNING_PATH_EVENT_NAMES.PATH_UPDATED` — literally the string
  `"learning-path:updated"`, since 6 other agents' consumers hardcode this as their
  fallback constant when requiring learning-path defensively
  (`try { require("../../learning-path") } catch {}`).
- Mounted: `app.js` -> `/learning-path`; bootstrapped in `server.js`.
- No prerequisite-graph model exists in this LMS — `Module.order`/`Lesson.order` are the
  de facto prerequisite chain. No ranking/scoring engine (unlike
  Recommendation/CareerRecommendation) — fixed priority per recommendation type
  (NEXT_LESSON, NEXT_MODULE, REVISION, PREREQUISITE, PACE_ADJUSTMENT), built directly from
  sequencer/pace/revision engine outputs. No paired history table (breaks from the
  retire-and-snapshot convention deliberately — spec fixed the model list at exactly 6).
  `LearningGoal` has no write endpoint (read-ready only, nothing populates it via this
  agent's own API).

## 10. placement — `modules/placement`
- Folders: `ai/ (7 files: interviewReadinessEngine.js, jobMatchEngine.js,
  opportunityRanker.js, placementReadinessScorer.js, preparationSuggestionEngine.js,
  resumePortfolioScorer.js, skillGapDetector.js) constants/ (companies.seed.js,
  opportunities.seed.js) controllers/ dto/ events/ index.js
  integrations/jobPortalProvider.js middleware/ repositories/ (10) routes/ schedulers/
  (catalogRefresh, dailySweep) services/ (context/studentContextBuilder.js,
  placement.service.js) types/ utils/ validators/`.
- Exports: `router, bootstrap, subscribe, PLACEMENT_EVENT_NAMES, recalculate,
  generateForStudent, getProfile`.
- Events: `PLACEMENT_EVENT_NAMES.PLACEMENT_UPDATED`.
- Mounted: `app.js` -> `/placement`; bootstrapped in `server.js`.
- Structural sibling of Career — same domain-fabrication resolution shape:
  `Company`/`JobOpportunity`/`InternshipOpportunity`/`PlacementDrive` are its own seeded
  catalog (idempotently upserted every boot, needs `@@unique([companyId, title])` on all
  3 catalog models). `integrations/jobPortalProvider.js` is a real adapter honestly
  returning empty listings (no fake live feed). `interviewReadinessEngine.js`
  redistributes weight instead of trusting a fabricated default — below
  `MIN_INTERVIEWS_FOR_HISTORY_WEIGHT` (2), the neutral 50%-pass-rate placeholder
  contributes **zero** weight rather than blending in a made-up number.
- Consumed by: nothing (no agent above it in the graph).
- Consumes: `career.getFullState`.

## 11. admin-intelligence — `modules/admin-intelligence`
- Folders: `constants/ controllers/ dto/ events/ exporters/ (csv, json) index.js
  middleware/resolveAdminAccess.middleware.js middleware/validateQuery.middleware.js
  repositories/ (10) schedulers/ (dailySweep, reportScheduler) services/
  (adminIntelligence.service.js, context/institutionContextBuilder.js, domain/ — 8
  engine files) types/ utils/ validators/`.
- Exports: `router, bootstrap, subscribe, ADMIN_INTELLIGENCE_EVENT_NAMES, recalculate,
  generateInsights, getDashboard`.
- Events: `ADMIN_INTELLIGENCE_EVENT_NAMES.ADMIN_INSIGHT_UPDATED`.
- Mounted: `app.js` -> `/admin-intelligence`; bootstrapped in `server.js`.
- First agent built after the original "10 agents" milestone; sits one layer above
  Analytics (see ARCHITECTURE.md). Domain-fabrication gaps resolved by precedent:
  "Department" = `Course.category`; "Faculty" = `User.role=INSTRUCTOR`; "Semester" report
  boundaries are its own configurable Jan 1/Jul 1 approximation.
  `ComplianceAudit` is a genuinely append-only audit ledger (never updated) whose
  `AI_DECISION_QUALITY` check scans TeacherInsight's real `confidenceScore` field.
  10 models double as their own time-series tables (date-bucketed `@@unique`). Single
  global 60s debounce (not per-scope) backed by a daily sweep. ADMIN-only access, no
  student/instructor branching at all.
- Consumes: `analytics.getPlatformKPIs/getCourseKPIsBatch/getInstructorKPIsBatch`,
  `teacherInsights.getTeacherDashboard`, `studentState.getHighRiskStudents`.

## 12. mentor — `modules/mentor`
- Folders (see ARCHITECTURE.md for the dual-chain explanation): `constants/
  (memoryKeys.constants.js, promptTemplates.seed.js) context-engine/ (5 files)
  controllers/mentor.controller.js (built, unwired) dto/ index.js intent-engine/
  (classifier.js, index.js, keywordMap.js) llm/ (anthropicProvider.js,
  fallbackProvider.js, index.js) memory/ (factExtractor.js, index.js, summarizer.js)
  mentor.controller.js (flat, active) mentor.routes.js (flat, active, required by
  index.js) mentor.service.js (flat, active, uses shared modules/llm i.e. Ollama)
  mentor.validation.js (flat, active) mentorPrompt.builder.js (flat, active) middleware/
  (resolveMentorActor, validateQuery) orchestrator/ (agentSelector.js, index.js, unwired)
  prompt-builder/ (index.js, promptAssembler.js, unwired) repositories/ (8)
  routes/mentor.routes.js (built, unwired) services/mentor.service.js (exports
  chat/streamChat via index.js, unwired from router) tools/ (admin.tools.js,
  instructor.tools.js, student.tools.js, tool.registry.js — used by the active flat
  mentor.service.js) types/ utils/ validators/mentor.validator.js (unwired)`.
- Exports: `router, bootstrap, chat, streamChat`. No `subscribe`/`*_EVENT_NAMES` —
  pure consumer, never produces events other agents subscribe to.
- Mounted: `app.js` -> `/mentor`; bootstrapped in `server.js`.
- First agent with a genuine non-deterministic external dependency (LLM). Two working
  LLM paths existed side by side: the active router path uses the shared
  `modules/llm` Ollama gateway; the unwired subfolder path uses
  `mentor/llm/anthropicProvider.js` (real Anthropic SDK streaming) with
  `mentor/llm/fallbackProvider.js` as the honest non-generative default when no API key
  is set.
- Models named `MentorConversation`/`MentorMessage` (not `Conversation`/`Message`) to
  avoid colliding with the pre-existing, unrelated human-to-human chat feature
  (`modules/conversations`, `modules/messages`, `src/socket/`) that already used those
  names.
- Activated previously-dead observation event types: `AI_HINT_REQUESTED`/`AI_CHAT_*`
  were real event types Analytics'/Recommendation's code already read, but nothing had
  ever published them until mentor's build — every STUDENT chat turn now calls
  `observation.publishEvent(...)`, fire-and-forget, never allowed to affect the chat
  response on failure.
- Access control breaks the pattern every prior agent used: NOT role-gated — all 3
  roles can use it. Ownership-based instead (`assertOwnsConversation` — no ADMIN
  override). Role instead selects which peer agents get queried
  (`orchestrator/agentSelector.js`'s declarative `(role, intent) -> agent calls` table)
  and which system-prompt persona loads.
- Intent Engine: deterministic keyword/phrase scoring (11 intents), not an ML classifier
  — no such library exists in this repo. Below `INTENT_CONFIDENCE_THRESHOLD` (40), the
  pipeline short-circuits to a clarifying question before any agent/LLM call.
- Every fact in the merged context is provenance-labeled `${agentName}.${method}`
  (`context-engine/mergeContext.js`) — no fabricated conflict-resolution engine, since
  every agent owns a disjoint slice of context.
- `utils/safeInvoke.util.js` wraps every agent call with an 8s timeout race + try/catch,
  always resolving to `{status: SUCCESS|FAILURE|TIMEOUT, ...}` — one broken peer agent
  never breaks a turn.
- Two-tier memory: last 10 messages ride verbatim; past 20 messages, older turns compact
  into `ConversationSummary`. Across conversations, `MentorMemory` is a small fixed
  vocabulary fact ledger (`LAST_INTENT`, `CAREER_GOAL`, `LAST_DISCUSSED_COURSE`,
  `LAST_STUDY_TOPIC`) — not a fabricated semantic/vector memory (no vector-store
  dependency exists in this stack).
- First SSE endpoint in this codebase (`POST /mentor/conversations/:id/messages/stream`,
  consumed by the frontend's `MentorWindow.jsx` via a raw `fetch`), separate from the
  existing Socket.IO layer (purpose-built for the unrelated human-chat feature).
- Consumes (via `safeInvoke` wrappers around each): observation, student-state,
  assessment, recommendation, motivation, teacher-insights, career, learning-path,
  placement, admin-intelligence — all 11 other agents.
