# Environment Variables

Full sanitized key list (names only, values redacted) is at `reference/env-keys-only.txt`.
No `.env.example`/`.env.sample` file exists anywhere in this repo — `.env` is the only env
file, and it was never committed to git.

| Variable | Purpose | Used by | Required/Optional | Example format |
|---|---|---|---|---|
| `ANTHROPIC_API_KEY` | Anthropic Claude API key for real LLM calls | `mentor/llm/anthropicProvider.js` (unwired chain), `assessment/llm/anthropicProvider.js` (was actually the entry-assessment carve-out's — see ARCHITECTURE.md, now lives in `modules/entry-assessment/llm/`) | Optional — both integrations have an honest, explicitly-labeled non-generative fallback when unset (`mentor/llm/fallbackProvider.js`, `assessment` carve-out's `llm/fallbackQuestionBank.js`) | `<ANTHROPIC_API_KEY>` |
| `OLLAMA_BASE_URL` | Base URL of a local Ollama server | shared `modules/llm/ollama.client.js` — used by mentor's active (flat) chain, plus non-agent `adaptive-learning` and `learner-model` | Required for the shared LLM gateway to function; not agent-exclusive, was **not removed** | `<OLLAMA_BASE_URL>` |
| `OLLAMA_MODEL` | Which Ollama model to call | same as above | Same as above | `<OLLAMA_MODEL>` |
| `OLLAMA_TIMEOUT_MS` | Request timeout | same as above | Same as above | `<NUMBER>` |
| `OLLAMA_THINK_TIMEOUT_MS` | Extended timeout for "thinking" models | same as above | Same as above | `<NUMBER>` |
| `OLLAMA_MAX_OUTPUT_TOKENS` | Output token cap | same as above | Same as above | `<NUMBER>` |

No `OBSERVATION_*`, `MENTOR_*`, `AGENT_*`, or any other agent-name-prefixed env var was
ever defined in this project. In the environment this removal was performed in,
`ANTHROPIC_API_KEY` was **not set**, meaning both Anthropic-backed code paths were already
running in fallback mode before removal — restoration does not change live LLM behavior by
itself; setting `ANTHROPIC_API_KEY` is a separate, optional step.

No secrets, keys, or credential values are recorded anywhere in this backup — only variable
names.
