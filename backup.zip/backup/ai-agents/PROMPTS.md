# Prompts, Seed Data & LLM Configuration

## Mentor

- `constants/promptTemplates.seed.js` — seeds the `PromptTemplate` model with
  role-scoped system prompt templates (STUDENT/INSTRUCTOR/ADMIN personas). Full content
  preserved verbatim at `source/mentor/constants/promptTemplates.seed.js`.
- `mentorPrompt.builder.js` (flat, active chain) and `prompt-builder/promptAssembler.js`
  (subfolder, unwired chain) — both build the final prompt sent to the LLM; see
  ARCHITECTURE.md for why two parallel implementations exist. Preserved verbatim at
  `source/mentor/`.
- `context-engine/mergeContext.js` — merges each queried agent's real data into the
  prompt context, provenance-labeled `${agentName}.${method}` per fact (no fabricated
  data ever enters the prompt).
- `intent-engine/keywordMap.js` — the 11-intent keyword/phrase scoring table (weight 20
  single-word, weight 35 multi-word phrases), `INTENT_CONFIDENCE_THRESHOLD = 40`.
- `constants/memoryKeys.constants.js` — fixed vocabulary for cross-conversation memory
  facts: `LAST_INTENT`, `CAREER_GOAL`, `LAST_DISCUSSED_COURSE`, `LAST_STUDY_TOPIC`.
- `llm/anthropicProvider.js` (unwired chain) — real Anthropic SDK integration
  (`generate()` + token-streaming `stream()` via `.on("text", ...)`).
- `llm/fallbackProvider.js` — the honest, non-generative default used whenever no LLM is
  configured: builds a deterministic reply directly from the merged context's real bullet
  points, never invents prose.
- `mentor.service.js` (flat, active chain) uses the shared `modules/llm/llm.service.js`
  (Ollama) instead of `mentor/llm/`.

## Career

- `constants/industryRoles.seed.js` — 10 seeded industry roles with `requiredSkills`
  weight maps, idempotently upserted every boot (`industryRoleRepository.ensureSeeded`).
  This IS the "Industry Skill Taxonomy" the spec asked for — not pulled from anywhere
  external.
- `ai/jobMarketProvider.js` — `getIndustryTrends()` adapter, defaults to the same static
  seed data; a real provider (LinkedIn/Naukri/Indeed) would implement the same contract.

## Placement

- `constants/companies.seed.js` (6 companies), `constants/opportunities.seed.js` (9 jobs,
  5 internships, 2 drives) — uses the same skill-name vocabulary as Career's
  `industryRoles.seed.js` so real matching produces meaningful results end to end.
  Idempotently upserted every boot.
- `integrations/jobPortalProvider.js` — `getExternalListings()` adapter, honestly returns
  `{jobs: [], internships: []}` rather than faking a live feed.

## LLM configuration reference (shared, not agent-exclusive — kept in the live codebase)

`modules/llm/llm.config.js` — Ollama connection settings (`OLLAMA_BASE_URL`,
`OLLAMA_MODEL`, timeouts). Not part of this removal; still used by `adaptive-learning` and
`learner-model`.

Full verbatim content of every prompt/seed/LLM file listed above is preserved in
`source/<agent>/` — this document is an index and summary, not a substitute for reading the
actual files when restoring.
