# Restoration Steps

Ordered checklist. Read `AGENT_RESTORATION_PROMPT.md` first if giving this to a fresh
Claude Code session — it's the self-contained version of this checklist with full context.

1. **Restore source**: copy each `source/<agent>/` directory back to
   `lms-api/src/modules/<agent>/`.
2. **Restore dependencies**: `@anthropic-ai/sdk` and `modules/llm` (Ollama gateway) were
   never removed (see README.md) — nothing to reinstall on the backend unless the live
   `package.json` has drifted since removal (diff against
   `reference/package.json.pre-removal` to check). On the frontend, run
   `npm install markdown-to-jsx` in `lms_web_demo/` — it was uninstalled as part of
   removal since it was exclusively used by `MentorMarkdown.jsx` (see `MANIFEST.md`).
3. **Restore database**: hand-merge `reference/schema.prisma.pre-removal`'s agent model/
   enum blocks (see `DATABASE.md` for the exact per-agent list) into the CURRENT
   `schema.prisma` — do not blindly overwrite the whole file, since core models may have
   changed since removal. Do NOT re-add `LearningEvent`, `StudentActivityState`,
   `ConceptMastery`, `KnowledgeGap`, `StudentState`, `EntryAssessment`,
   `StudentCourseState` — these were never removed (verify they're already present before
   assuming they need restoring). Watch specifically for `MasteryStatus`/`GapStatus` —
   they look like Assessment-agent-only enums but are actually used by the kept
   `ConceptMastery`/`KnowledgeGap` models too; they were never removed either (see
   `DATABASE.md`'s correction note). After restoring, run `npx prisma validate` before
   `db push` — it will catch any relation/enum mismatch immediately, the same way it
   caught two real mistakes during removal.
3a. **Optionally reseed data**: `backup/ai-agents/data/*.json` holds every row from every
   removed table at the moment of removal (one JSON file per table, plus
   `_export-summary.json`). This is historical data, not required for the code to work —
   restoring the schema/code alone gives every agent a fresh empty state. Only reseed if
   the user explicitly wants the old computed data back (recommendations, conversations,
   analytics history, etc.) — reseeding needs care around foreign keys that may no longer
   resolve (e.g. a `Recommendation` row referencing a `Course`/`StudentProfile` that was
   deleted in the meantime).
4. **Restore migrations**: n/a — this project has no migrations folder; schema changes are
   applied via `prisma db push` by established convention (confirmed with the user twice).
5. **Restore environment variables**: `ANTHROPIC_API_KEY` is optional (see
   ENVIRONMENT.md) — both LLM integrations have honest fallbacks without it. No other
   agent-specific env var ever existed.
6. **Restore configuration**: bootstrap order and debounce/scheduler cadences are
   documented in `CONFIGURATION.md` — preserve them exactly, don't redesign.
7. **Restore APIs / routes**: re-add the 12 `require`+`app.use` pairs to `app.js` (see
   `API_REFERENCE.md` for exact mount prefixes; `reference/app.js.pre-removal` for exact
   original line placement) and the 11 `require`+`bootstrap()` pairs to `server.js` in the
   bootstrap order from `CONFIGURATION.md`.
7a. **Restore the auth.controller.js touchpoint**: `modules/auth/auth.controller.js` (core,
   not one of the 12) used to fire `observation.publishEvent` on every student
   login/logout — this was removed as part of the agent removal and is NOT restored
   automatically by step 1 (it's core code, not agent code). See
   `DEPENDENCY_MAP.md`'s "Core-module touchpoint" section and
   `reference/core-module-touchpoints/auth.controller.js.pre-removal` for the exact code
   to re-add.
8. **Restore agent orchestration**: mentor's `orchestrator/agentSelector.js` declarative
   `(role, intent) -> agent calls` table and `utils/safeInvoke.util.js`'s 8s-timeout
   wrapper come back automatically with the source restore in step 1 — no separate action
   needed, just confirm they're present.
9. **Restore frontend integration**: for the 3 agents with real frontend code (mentor,
   teacher-insights, learning-path — see `DEPENDENCY_MAP.md`/frontend section), copy
   `source/frontend/<agent>/` back to its original `lms_web_demo/src/...` path (see
   `MANIFEST.md` for exact original paths), then re-add the removed lines to
   `DashboardLayout.jsx` (mentor mount), `navigationItems.ts` (teacher-insights nav
   entries), `queryKeys.js` (the 3 agents' query keys), and `learn/[courseId]/page.jsx`
   (learning-path's `PersonalizedPathCard` render).
10. **Restore background jobs**: schedulers come back automatically with each agent's
    source restore (step 1) and its `bootstrap()` call (step 7) — `node-cron` (already a
    project dependency, never removed) drives them.
11. **Run migrations / apply schema**: `npx prisma db push` then `npx prisma generate`.
12. **Run tests**: none existed for any of the 12 agents before removal (confirmed — zero
    `tests/` folders, zero references in the top-level `test/`). Nothing to run here beyond
    the project's existing `course-import`-focused test suite, which was never affected.
13. **Run build**: `npm run build` (frontend), confirm no broken imports.
14. **Validate every agent**: see `VALIDATION.md`.
15. **Validate Mentor orchestration**: confirm a chat turn successfully calls at least a
    few of the other 11 agents via `safeInvoke` (check `AgentInvocation` rows get created)
    and that `observation.publishEvent` fires for `AI_HINT_REQUESTED`/`AI_CHAT_*` on each
    turn.
16. **Validate Admin Intelligence**: confirm `getDashboard` successfully calls
    `analytics.getPlatformKPIs`, `teacherInsights.getTeacherDashboard`, and
    `studentState.getHighRiskStudents` without error (these 3 getters must all be back
    from steps 1-7 before Admin Intelligence's own bootstrap runs, given the bootstrap
    order in `CONFIGURATION.md`).
