# Database — Prisma Models & Enums

Full pre-removal schema is at `reference/schema.prisma.pre-removal`. This file explains
per-agent ownership, what was **kept** vs **removed**, and why.

## Global structural fact

Every agent-owned model carries a scalar FK column (`studentId`/`courseId`/`userId`/etc.)
pointing **into** a core model (`StudentProfile`, `Course`, `User`). No core table ever had a
real FK column pointing into an agent table. The only footprint on core models was a virtual
Prisma back-relation array field (e.g. `StudentProfile.recommendations Recommendation[]`) —
not a DB column, just a schema-level relation declaration, removed along with the FK-owning
side.

## KEPT — do not re-add on restore, they never left

| Model | Owned (nominally) by | Why kept |
|---|---|---|
| `LearningEvent` | observation | `modules/learner-model` (separate feature, not one of the 12, has its own frontend) reads it directly via raw `prisma.learningEvent.*` with no dependency on observation's module code. |
| `StudentActivityState` | observation | Same reason — `learner-model` and `analytics`'s calculators both read it directly. |
| `ConceptMastery` | assessment | `learner-model` reads/writes it directly (`prisma.conceptMastery.*`) for its own mastery calculations. |
| `KnowledgeGap` | assessment | `learner-model` reads/writes it directly. Also written to by core `quizzes/quiz.service.js` (`prisma.knowledgeGap.update(...)` on quiz submission) — this write required no code change since the table was never dropped. |

Their `StudentProfile` back-relations (`learningEvents`, `activityState`,
`conceptMasteries`, `knowledgeGaps`) were likewise kept.

**Also never touched** (not agent-owned in the first place, despite naming or physical
location that suggested otherwise):
- `StudentState` — a lightweight "resume where you left off" pointer model
  (`studentId, courseId, moduleId?, lessonId?, contentId?, timestamp?`). Despite the name
  matching the student-state agent, it is **never referenced anywhere inside
  `modules/student-state/`** — it's used exclusively by core `modules/courses`,
  `modules/students`, and `modules/learner-model`. Its `StudentProfile.studentState
  StudentState[]` and `Course.studentStates StudentState[]` back-relations were preserved.
- `EntryAssessment`, `StudentCourseState` — owned by the entry-assessment carve-out (see
  ARCHITECTURE.md), not one of the 12 agents. Untouched by this removal.
- `LearningMode` enum (`SMART_REVISION/STANDARD_LEARNING/DEEP_LEARNING`) — defined in the
  schema near `StudentCourseState` but referenced by zero fields anywhere; a pre-existing
  orphaned enum, unrelated to this removal, left as-is.

## REMOVED — per agent

### observation (2 models removed)
- `LearningEvent` — **kept**, see above. (Only its non-observation-specific usage
  survives; the observation module's own code that wrote/read it via `publishEvent`/
  `getStudentEventLog` is gone.)
- `StudentActivityState` — **kept**, see above.

Enums removed: `EventType`, `EventCategory`. *(Note: since `LearningEvent`/
`StudentActivityState` were kept and still reference these enum types as field types,
`EventType`/`EventCategory` were actually kept too, not removed — restoration does not need
to reintroduce them. See the live `schema.prisma` for the final state.)*

### student-state (7 models, 1 kept as part of entry-phase not this agent)
Removed: `StudentLearningState`, `StudentProgress`, `StudentPerformance`,
`StudentEngagement`, `StudentBehavior`, `StudentRisk` (all intra-agent, cascading off
`StudentLearningState`).
Not removed (not this agent's — entry-phase): `StudentCourseState`.

### assessment (6 models removed, 1 entry-phase model untouched)
Removed: `Assessment`, `AssessmentAttempt`, `AssessmentResult`, `ReassessmentPlan`.
Kept (shared with learner-model, see above): `ConceptMastery`, `KnowledgeGap`.
Not removed (not this agent's — entry-phase): `EntryAssessment`.
Enums removed: `AssessmentType`, `AssessmentStatus`, `ReassessmentStatus`,
`ReassessmentPriority`.
**Enums kept (discovered during actual removal, corrected here):
`MasteryStatus` and `GapStatus` were initially assumed to be Assessment-agent-only, but
`ConceptMastery.status` and `KnowledgeGap.status` (both kept models) use them directly —
`npx prisma validate` caught this immediately when they were removed. Both enums were
restored right after `KnowledgeGap`'s model block in the live schema.** This is a good
example of why `prisma validate` (and a real boot-check) matter even after a careful
manual dependency read — schema-level type usage doesn't always show up in a services/
repositories code-grep.
Entry-phase-only enums kept (not this agent's): `EntryAssessmentStatus`,
`EntryKnowledgeLevel`.

### recommendation (5 models removed)
`Recommendation`, `RecommendationHistory`, `RecommendationFeedback`, `RecommendationRule`,
`RecommendationAnalytics`.
Enums removed: `RecommendationType`, `RecommendationPriority`, `RecommendationStatus`,
`RecommendationFeedbackAction`, `RecommendationRetiredReason`.

### motivation (6 models removed)
`MotivationAction`, `MotivationHistory`, `ReminderSchedule`, `StudentStreak`,
`EngagementTrend`, `MotivationAnalytics`.
Enums removed: `MotivationActionType`, `MotivationPriority`, `MotivationStatus`,
`MotivationRetiredReason`, `ReminderCadence`, `StreakStatus`.

### teacher-insights (7 models removed)
`StudentAlert`, `CourseInsight`, `CourseHealth`, `TeachingRecommendation`,
`TeacherInsight`, `InsightHistory`, `InsightAnalytics`.
Enums removed: `AlertType`, `CourseInsightType`, `TeachingRecommendationType`,
`TeacherReportType`, `InsightSourceModel`, `InsightRetiredReason`, `InsightPriority`,
`InsightStatus` (the last two were also used by admin-intelligence's models — safe to
remove wholesale since admin-intelligence was removed in the same pass).

### analytics (7 models removed)
`KPI`, `AnalyticsHistory`, `AnalyticsSnapshot`, `DashboardMetric`, `TrendAnalysis`,
`Forecast`, `Report`. None of these 7 had any `@relation` at all (fully
soft/polymorphic via `scopeType`/`scopeId`) — zero FK cleanup needed on core models for
this agent.
Enums removed: `AnalyticsScopeType`, `AnalyticsMetricKey`, `AnalyticsTrendDirection`,
`AnalyticsReportType`.

### career (9 models removed)
`IndustryRole`, `CareerGoal`, `CareerProfile`, `SkillAssessment`, `SkillGap`,
`CareerRecommendation`, `CareerRecommendationHistory`, `CareerRoadmap`,
`CareerReadinessHistory`.
Enums removed: `CareerRecommendationType`, `CareerPriority`, `CareerRecommendationStatus`,
`CareerRetiredReason`, `IndustryReadinessLevel`, `CareerConfidenceLevel`,
`SkillGapSeverity`, `SkillGapStatus`, `RoadmapHorizon`, `RoadmapStatus`,
`CareerGoalStatus`.
*(Known pre-existing schema inconsistency, preserved in this doc for restoration
awareness: `CareerRecommendationHistory.recommendationId` had no `@relation` to
`CareerRecommendation` — unenforced, unlike `RecommendationHistory`'s equivalent FK
elsewhere. Not something this removal introduced or needs to fix.)*

### learning-path (6 models removed — matches the spec's fixed "6 named models")
`LearningPath`, `LearningRecommendation`, `StudyPlan`, `LearningMilestone` (had an
**enforced** FK into `Course`, not just `StudentProfile`), `RevisionPlan`, `LearningGoal`
(also enforced FK into `Course`, no write endpoint ever existed for it). `Course`'s
`learningMilestones`/`learningPathGoals` back-relations removed accordingly.
Enums removed: `LearningPathDifficultyAdjustment`, `LearningRecommendationType`,
`LearningRecommendationPriority`, `LearningRecommendationStatus`, `StudyPlanType`,
`MilestoneType`, `MilestoneStatus`, `RevisionPlanStatus`, `LearningGoalType`,
`LearningGoalStatus`.

### placement (10 models removed)
`Company`, `JobOpportunity`, `InternshipOpportunity`, `PlacementDrive`, `JobMatch`,
`Application`, `Interview`, `Offer`, `ResumeReview`, `PlacementProfile`.
Enums removed: `OpportunityType`, `EmploymentType`, `OpportunityStatus`,
`OpportunitySource`, `JobMatchPriority`, `JobMatchStatus`, `ApplicationStatus`,
`InterviewType`, `InterviewStatus`, `InterviewOutcome`, `OfferStatus`, `DriveStatus`.

### admin-intelligence (10 models removed)
`InstitutionHealth`, `DepartmentAnalytics`, `FacultyAnalytics`, `AdminInsight`,
`StrategicRecommendation`, `ComplianceAudit`, `CapacityForecast`, `AdminAlert`,
`ExecutiveReport`, `GovernanceMetric`. Like analytics, zero `@relation` fields across all
10 — pure soft/polymorphic, no FK cleanup needed on core models.
Enums removed: `AdminScopeType`, `AdminInsightCategory`, `AdminInsightStatus`,
`StrategicRecommendationType`, `StrategicRecommendationStatus`, `ComplianceCheckType`,
`ComplianceAuditOutcome`, `ComplianceSeverity`, `CapacityResourceType`,
`ExecutiveReportType`, `GovernanceMetricKey`, `AdminAlertType`, plus its shared use of
`InsightPriority`/`InsightStatus` (removed with teacher-insights, see above).

### mentor (8 models removed)
`MentorConversation`, `MentorMessage`, `ConversationContext`, `AgentInvocation`,
`MentorMemory`, `ConversationSummary`, `PromptTemplate`, `ResponseFeedback`.
`User`'s `mentorConversations`/`mentorMemories`/`mentorFeedback` back-relations removed
accordingly.
Enums removed: `MentorMessageRole`, `MentorIntent`, `MentorConversationStatus`,
`AgentInvocationStatus`, `FeedbackRating`.
*(Note: `AgentInvocation.agentName` was a free-text label, never an enforced relation to
any of the 12 agent modules — no FK breakage from removal, but historical rows in a
restored `AgentInvocation` table would reference agent names that, at some point, didn't
exist in code.)*

## Core models touched — surgical edits only, models themselves untouched

- **`StudentProfile`** — the central hub. Its ~20 entry-phase scalar columns
  (`gender`, `country`, ..., `technicalSkills`) and the pre-existing base columns
  (`education`, `phone`, etc.) were never touched. Only the back-relation array fields
  added by each of the 12 agents were removed (one or more per agent, enumerated in each
  agent's section above); the entry-phase relations (`entryAssessments`, `courseStates`)
  and the unrelated core `studentState StudentState[]` relation were preserved.
- **`Course`** — back-relations from observation (`learningEvents` — kept, see above),
  teacher-insights (`studentAlerts`, `courseInsights`, `courseHealth`,
  `teachingRecommendations`, `teacherInsights` — removed), learning-path
  (`learningMilestones`, `learningPathGoals` — removed, these were enforced FKs). Entry-phase
  relations (`entryAssessments`, `studentCourseStates`) preserved.
- **`User`** — back-relations from mentor (`mentorConversations`, `mentorMemories`,
  `mentorFeedback` — removed). No other agent touched `User`.

## Applying the schema change

This project has no `prisma/migrations/` folder — schema changes were always applied via
`prisma db push` by convention (confirmed: `prisma:migrate` script exists in `package.json`
but was never actually used to generate a committed migration history; the user has twice
declined baselining one). Restoration should do the same: hand-edit `schema.prisma` back to
`reference/schema.prisma.pre-removal`'s agent sections (merged with whatever core-model
changes happened in the meantime), then `prisma db push` + `prisma generate`.
