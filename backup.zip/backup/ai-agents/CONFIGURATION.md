# Configuration — Bootstrap Order, Schedulers, Debounce Windows

## Bootstrap order (from `server.js`, pre-removal)

`observation` has no bootstrap call (passive sink). The other 11 were bootstrapped in this
exact order — restoration should preserve it, since it follows the modules' own documented
dependency chain (each later module's spec assumed the earlier ones already existed):

```
1. student-state
2. assessment
3. recommendation
4. motivation
5. teacher-insights
6. analytics
7. career
8. learning-path
9. placement
10. admin-intelligence
11. mentor
```

## Recompute / debounce policy per agent

| Agent | Trigger | Debounce/cadence |
|---|---|---|
| student-state | `observation.EVENT_CREATED` | 5s debounce (per-student) |
| assessment | `observation.EVENT_CREATED` | 5s debounce |
| recommendation | `student-state.STATE_UPDATED` + others | 5s debounce |
| motivation | `student-state.STATE_UPDATED` + `recommendation.RECOMMENDATION_UPDATED` (real cross-agent subscription — the first agent to consume a live peer's bus for real) | 5s debounce + scheduled sweeps (deadlineScan, engagementSweep, reminderDispatch) |
| teacher-insights | course-scoped, not per-student | schedulers: dailyClassSweep, monthlySummary, weeklySummary |
| analytics | STUDENT-scope: same 5s debounce as above. COURSE/INSTRUCTOR-scope: 60s-debounced off `TeacherInsightUpdated`, backed by hourly full sweep. PLATFORM-scope: daily-sweep only (never per-event — "don't real-time-recompute a full-population aggregation off a single student's event"). | schedulers: courseInstructorSweep, platformDailySweep, reportScheduler |
| career | `student-state.STATE_UPDATED` | schedulers: dailySafetySweep, industryTaxonomyRefresh (monthly, refreshes only market-derived fields, never curriculum-owned `requiredSkills`/`category`) |
| learning-path | `student-state.STATE_UPDATED` | scheduler: dailySweep |
| placement | `career.CAREER_PROFILE_UPDATED` | schedulers: catalogRefresh, dailySweep |
| admin-intelligence | none per-event — always recomputes the entire institution in one pass | single global 60s debounce (not per-scope), backed by daily sweep — the only honest trigger for "Enrollment Changes"/"Semester Starts-Ends"/etc., none of which have a real event anywhere across the other 11 modules |
| mentor | request-driven only (chat turn), no background recompute | n/a |

## Access control model per agent

| Agent | Model |
|---|---|
| student-state, assessment, recommendation, motivation, career, learning-path, placement | Student-scoped: student can see own data only |
| teacher-insights | Inverted: owning INSTRUCTOR (`Course.creatorId === User.id`) or ADMIN only — zero student access |
| analytics | Three-way: STUDENT locked to own STUDENT-scope; INSTRUCTOR locked to own INSTRUCTOR-scope + own COURSE-scope; PLATFORM-scope + Report/export ADMIN-only |
| admin-intelligence | ADMIN-only, no student/instructor branching at all (simplest gate of any agent) |
| mentor | Ownership-based, not role-gated — any of the 3 roles, own conversations only, no ADMIN override |

## Report export formats (analytics, admin-intelligence)

JSON and CSV only, hand-rolled CSV serializer. No PDF — no CSV/PDF-writer library exists in
this repo's dependencies (only `csv-parser`/`pdf-parse`, both read-only). This was an
honest, documented gap in the original build, not something restoration needs to "fix"
unless a PDF library is deliberately added.
