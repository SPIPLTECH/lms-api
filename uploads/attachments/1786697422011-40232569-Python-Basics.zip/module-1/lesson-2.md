# Variables and Data Types

In Python, variables are created when you assign a value to them without declaring types explicitly.

## Example Code

```python
# Declaring variables
course_name = "Python Basics"
total_students = 150
is_active = True

print(f"Welcome to {course_name}!")
```

## Notes

Always use snake_case for variable names in Python PEP 8 guidelines.
