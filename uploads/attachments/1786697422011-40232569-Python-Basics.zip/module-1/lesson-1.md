# What is Python?

Python is one of the easiest programming languages to learn. It is human-readable, versatile, and widely used in Web Development, Data Science, and Automation.

## Learning Objectives

- Understand Python syntax principles
- Install Python 3.12 interpreter
- Run your first script

## Video

intro.mp4

## PDF

notes.pdf

## Image

diagram.png

## External Link

https://python.org
