# Conditional Statements

Use if, elif, and else statements to make decisions in your code based on dynamic conditions.

## Learning Objectives

- Understand boolean logic
- Construct multi-branch conditional statements
