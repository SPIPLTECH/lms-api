# Defining Functions

Functions are reusable blocks of code that perform a specific action when called.

## Code Example

```python
def greet_student(name):
    return f"Hello, {name}! Welcome to Module 2."

message = greet_student("Alex")
print(message)
```
